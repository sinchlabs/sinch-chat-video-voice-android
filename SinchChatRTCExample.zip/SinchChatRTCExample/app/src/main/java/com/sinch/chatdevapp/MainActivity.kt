package com.sinch.chatdevapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.google.firebase.FirebaseApp
import com.google.firebase.messaging.FirebaseMessaging
import com.sinch.chat.sdk.*
import com.sinch.sdk.rtc.*
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        FirebaseMessaging.getInstance().token.addOnCompleteListener { task ->
            if (task.isSuccessful) {
                initializeSinchChatSDK(task.result)
            } else {
                initializeSinchChatSDK(null)
            }
            setIdentity()
        }

    }

    private fun initializeSinchChatSDK(deviceToken: String?) {
        val options = SinchInitializationOptions(deviceToken)
        val sinchRTCPlugin = SinchVideoRTCPluginSDK(
            {
                return@SinchVideoRTCPluginSDK this
            },
            "{{ RTC_APPLICATION_KEY }}",
            "{{ RTC_APPLICATION_SECRET }}",
            "{{ FIREBASE_SENDER_ID }}",
        )

        options.plugins = listOf(sinchRTCPlugin)
        SinchChatSDK.initialize(applicationContext, options)
        setIdentity()
    }

    private fun setIdentity() {
        // two types of identity
        // anonymouse
//        val anonymousIdentity = SinchIdentity.Anonymous
        // self signed
        val secret = "{{ SINCH_PUSH_SECRET }}"
        val clientID = "{{ SINCH_PUSH_CLIENT_ID }}"
        val projectID = "{{ SINCH_PUSH_PROJECT_ID }}"
        val configID = "{{ SINCH_PUSH_CONFIG_ID }}"

        val internalUserID = "example@domain.com"
        val signedUserID = HmacSha512.generate(internalUserID, secret)
        val signedIdentity = SinchIdentity.SelfSigned(internalUserID, signedUserID)

        val config = SinchConfig(clientID, projectID, configID, SinchRegion.EU1, "")


        SinchChatSDK.setIdentity(config, signedIdentity) { result ->
            if (result.isSuccess) {
                showChat()
            }
        }

    }

    private fun showChat() {
        SinchChatSDK.chat.start(this)
    }
}

object HmacSha512 {

    fun generate(message: String, key: String): String {
        val mac: Mac = Mac.getInstance("HmacSHA512")
        mac.init(SecretKeySpec(key.encodeToByteArray(), mac.algorithm))
        return mac.doFinal(message.encodeToByteArray())
            .joinToString(separator = "") { "%02x".format(it) }
    }
}
