package com.sinch.chatdevapp

import com.google.firebase.messaging.RemoteMessage
import com.sinch.chat.sdk.SinchChatSDK
import com.sinch.sdk.rtc.SinchPushNotificationService

class AppFirebaseMessagingService : SinchPushNotificationService() {

    override fun onNewToken(p0: String) {
        super.onNewToken(p0)
        SinchChatSDK.push.onNewToken(p0)
    }

    override fun onMessageReceived(p0: RemoteMessage) {
        super.onMessageReceived(p0)

        if (SinchChatSDK.push.onMessageReceived(p0)) {
            // push handled by SinchChatSDK
        }
    }
}
